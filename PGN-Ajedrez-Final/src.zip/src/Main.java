import controlador.ControladorAjedrez;
import modelo.Tablero;
import vista.VistaTablero;

public class Main {
//    public static void main(String[] args) {
//        Tablero modelo = new Tablero();            // Modelo
//        VistaTablero vista = new VistaTablero();   // Vista
//        ControladorAjedrez controlador = new ControladorAjedrez(modelo, vista); // Controlador
//
//        // Guardar partida al finalizar (esto debe llamarse después de jugar)
//        controlador.guardarPartidaEnPGN("partida.pgn", "Jugador1", "Jugador2", "1-0");
//    }
}
